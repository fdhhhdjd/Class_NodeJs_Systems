//* LIB
import React from "react";

//* IMPORT
import { userAuthContext } from "../contexts/UserAuthContext";

const useAuth = () => React.useContext(userAuthContext);

export default useAuth;
