//* LIB
import React from "react";
import {
  GoogleOAuthProvider,
  GoogleLogin,
  googleLogout,
} from "@react-oauth/google";
import { jwtDecode } from "jwt-decode";
import axios from "axios";

const LoginGooglePopup = () => {
  const loginSuccess = (response) => {
    const result = jwtDecode(response?.credential);
    // const token = response.credential;

    axios
      .post("http://localhost:5000/api/v2/users/login/google/popup", result)
      .then((response) => {
        console.log("Kết quả từ API:", response.data);
      })
      .catch((error) => {
        console.error("Lỗi khi gọi API:", error);
      });
  };

  const onLoginFailure = (res) => {
    console.log("Login Failed:", res);
  };
  return (
    <React.Fragment>
      <GoogleOAuthProvider clientId={import.meta.env.VITE_APP_CLIENT_ID}>
        <GoogleLogin
          buttonText="Hello"
          onSuccess={loginSuccess}
          onError={onLoginFailure}
          width="100%"
          useOneTap
          auto_select
        />
        <button onClick={googleLogout}>Log</button>
      </GoogleOAuthProvider>
    </React.Fragment>
  );
};

export default LoginGooglePopup;
