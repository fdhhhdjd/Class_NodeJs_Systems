//* LIB
import React from "react";
import toast from "react-hot-toast";

//* LIB
import useAuth from "../../hooks/useAuth";
import ToastDisplay from "../../components/toast/ToastDisplay";

const NotificationFirebase = () => {
  const { requestForToken, onMessageListener } = useAuth();

  const [notification, setNotification] = React.useState({
    title: "",
    body: "",
  });

  const notify = () => toast(<ToastDisplay notification={notification} />);

  React.useEffect(() => {
    if (notification?.title) {
      notify();
    }
  }, [notification]);

  React.useEffect(() => {
    requestForToken();
    onMessageListener()
      .then((payload) => {
        console.log(payload);
        setNotification({
          title: payload?.notification?.title,
          body: payload?.notification?.body,
          image: payload?.notification?.image,
        });
      })
      .catch((err) => console.log("failed: ", err));
  });
  return <React.Fragment>NotificationFirebase</React.Fragment>;
};

export default NotificationFirebase;
