import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getMessaging } from "firebase/messaging";

const firebaseConfig = {
  apiKey: "AIzaSyA8q3faAmb_1aKQHVCJqspTllJ_u_paEpE",
  authDomain: "classfullstack-1606e.firebaseapp.com",
  projectId: "classfullstack-1606e",
  storageBucket: "classfullstack-1606e.appspot.com",
  messagingSenderId: "609467159343",
  appId: "1:609467159343:web:3ba7880c06e14f1b4747da",
  measurementId: "G-R2FNKW2M0L",
};

const app = initializeApp(firebaseConfig);

const auth = getAuth(app);
const messaging = getMessaging(app);

export { auth, messaging };
