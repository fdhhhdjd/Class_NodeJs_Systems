//* LIB
import React from "react";
import { Toaster } from "react-hot-toast";

//* IMPORT
import "./App.css";
import NotificationFirebase from "./pages/firebase/NotificationFirebase";

const App = () => {
  return (
    <React.Fragment>
      {/* 0. Toast */}
      <Toaster />

      {/* 1. Login Google PopUp */}
      {/* <LoginGooglePopup /> */}

      {/* 2. Notification Firebase */}
      <NotificationFirebase />
    </React.Fragment>
  );
};

export default App;
