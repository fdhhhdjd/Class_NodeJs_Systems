#!/bin/bash

ls -lh
# pwd
# find /