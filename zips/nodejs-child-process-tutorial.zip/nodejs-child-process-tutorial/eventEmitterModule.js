// eventEmitterModule.js
const EventEmitter = require('events');

class MyEmitter extends EventEmitter {}

const myEmitter = new MyEmitter();

// Xác định một hàm để kích hoạt sự kiện 'start'
function startTask() {
  console.log('Starting task...');
  myEmitter.emit('start');
}

// Xác định một hàm để kích hoạt sự kiện 'complete'
function completeTask() {
  console.log('Completing task...');
  myEmitter.emit('complete');
}



module.exports = {
  myEmitter,
  startTask,
  completeTask
};
