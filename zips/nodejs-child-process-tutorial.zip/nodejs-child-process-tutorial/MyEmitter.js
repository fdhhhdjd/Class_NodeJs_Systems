// app.js
const { myEmitter, startTask, completeTask } = require('./eventEmitterModule');

myEmitter.on('start', () => {
  console.log('Task has started.');
});

myEmitter.on('complete', () => {
  console.log('Task has completed.');
});

myEmitter.on('error', (err) => {
    console.error('Error occurred:', err);
});

startTask();

completeTask();
